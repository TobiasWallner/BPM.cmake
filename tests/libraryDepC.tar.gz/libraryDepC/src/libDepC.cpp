
#include <libC.hpp>
#include <string>

#include "libDepC.hpp"

namespace libDepC
{
    
    std::string get_number_str(){
        return std::to_string(libC::get_number());
    }

} // namespace libDepC
