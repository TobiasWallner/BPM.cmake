#pragma once


#include <string>

namespace libDepC
{
    
    std::string get_number_str();

} // namespace libDepC
