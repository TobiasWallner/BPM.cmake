#pragma once

namespace libB{

    bool libB();
    
}