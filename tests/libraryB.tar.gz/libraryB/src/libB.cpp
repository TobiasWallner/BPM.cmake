#include <libB/libB.hpp>

namespace libB{

    bool libB(){ return true; }
    
}