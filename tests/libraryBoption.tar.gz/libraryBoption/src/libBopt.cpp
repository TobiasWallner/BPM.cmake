#include <libBopt/libBopt.hpp>

#include <libB/libB.hpp>

namespace libBopt
{
    bool libBopt() { return libB::libB(); }
} // namespace libBopt