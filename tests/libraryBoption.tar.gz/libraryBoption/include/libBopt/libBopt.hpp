# pragma once

namespace libBopt
{
    bool libBopt();
} // namespace libBopt
