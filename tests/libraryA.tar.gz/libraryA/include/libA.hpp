#pragma once

#include <string>

namespace libA
{
    std::string version();
} // namespace libA
