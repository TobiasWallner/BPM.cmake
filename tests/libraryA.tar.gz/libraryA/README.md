Library with all versions from 

0.0.0

to 

10.10.10