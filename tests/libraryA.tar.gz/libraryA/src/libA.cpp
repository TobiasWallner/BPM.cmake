#include "libA.hpp"

#include <string>

namespace libA
{
    std::string version(){
        return "9.9.9";
    }
} // namespace libA
