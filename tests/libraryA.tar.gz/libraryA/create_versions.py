from pathlib import Path
import subprocess
import sys


OUTPUT_FILE = Path("src/libA.cpp")


def run_git(*args: str) -> None:
    result = subprocess.run(
        ["git", *args],
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        print(f"git {' '.join(args)} failed", file=sys.stderr)
        if result.stdout:
            print(result.stdout, file=sys.stderr)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        sys.exit(result.returncode)


def write_version_file(version: str) -> None:
    content = f'''#include "libA.hpp"

#include <string>

namespace libA
{{
    std::string version(){{
        return "{version}";
    }}
}} // namespace libA
'''
    OUTPUT_FILE.write_text(content, encoding="utf-8")


def main() -> None:
    for major in range(10):
        for minor in range(10):
            patch_start = 1 if (major == 0 and minor == 0) else 0
            for patch in range(patch_start, 10):
                version = f"{major}.{minor}.{patch}"
                tag = f"v{version}"

                write_version_file(version)

                run_git("add", str(OUTPUT_FILE))
                run_git("commit", "-m", f"Release {version}")
                run_git("tag", tag)

                print(f"Created {version} and tagged {tag}")


if __name__ == "__main__":
    main()