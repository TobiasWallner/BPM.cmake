#include "libC.hpp"

namespace libC
{
    int get_number(){
        return 52;
    }
} // namespace libC
