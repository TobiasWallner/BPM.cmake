#pragma once

namespace libC
{
    int get_number();
} // namespace libC
